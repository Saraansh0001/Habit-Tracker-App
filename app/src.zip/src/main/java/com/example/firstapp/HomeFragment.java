package com.example.firstapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.firstapp.adapters.HomeHabitAdapter;
import com.example.firstapp.data.HabitRepository;
import com.example.firstapp.models.Habit;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class HomeFragment extends Fragment {

    private ProgressBar pbMain;
    private TextView tvPercentage;
    private RecyclerView rvHabits;
    private HomeHabitAdapter habitAdapter;
    private HabitRepository habitRepository;
    private List<Habit> userHabits;
    private EditText etSearch;
    private ChipGroup cgCategories;
    private String currentCategory = "All";
    private String currentQuery = "";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        habitRepository = new HabitRepository(requireContext());
        userHabits = habitRepository.getUserHabits();

        pbMain = view.findViewById(R.id.pb_main_progress);
        tvPercentage = view.findViewById(R.id.tv_progress_percentage);
        rvHabits = view.findViewById(R.id.rv_habits_home);
        etSearch = view.findViewById(R.id.et_search_habits);
        cgCategories = view.findViewById(R.id.cg_categories);

        setupRecyclerView();
        setupSearchAndFilters();
        updateOverallProgress();
        setupFeatureClicks(view);

        view.findViewById(R.id.tv_all_features).setOnClickListener(v -> {
            loadFragment(new FeaturesFragment());
        });

        view.findViewById(R.id.tv_see_all_habits).setOnClickListener(v -> {
            if (getActivity() instanceof HomeActivity) {
                ((HomeActivity) getActivity()).navigateToTab(R.id.navigation_search);
            }
        });

        FloatingActionButton fab = view.findViewById(R.id.fab_add_habit);
        fab.setOnClickListener(v -> {
            if (getActivity() instanceof HomeActivity) {
                ((HomeActivity) getActivity()).loadFragment(new CreateChallengeFragment());
            }
        });

        return view;
    }

    private void setupFeatureClicks(View view) {
        View streaks = view.findViewById(R.id.ll_feature_streaks);
        if (streaks != null) {
            streaks.setOnClickListener(v -> loadFragment(new StreakCalendarFragment()));
        }

        View timer = view.findViewById(R.id.ll_feature_timer);
        if (timer != null) {
            timer.setOnClickListener(v -> loadFragment(new FocusTimerFragment()));
        }

        View goals = view.findViewById(R.id.ll_feature_goals);
        if (goals != null) {
            goals.setOnClickListener(v -> loadFragment(new WeeklyGoalsFragment()));
        }

        View journal = view.findViewById(R.id.ll_feature_journal);
        if (journal != null) {
            journal.setOnClickListener(v -> loadFragment(new DailyJournalFragment()));
        }
    }

    private void loadFragment(Fragment fragment) {
        if (getActivity() instanceof HomeActivity) {
            ((HomeActivity) getActivity()).loadFragment(fragment);
        }
    }

    private void setupSearchAndFilters() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                currentQuery = s.toString();
                habitAdapter.filter(currentQuery, currentCategory);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        cgCategories.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) {
                currentCategory = "All";
            } else {
                Chip chip = group.findViewById(checkedIds.get(0));
                currentCategory = chip.getText().toString();
            }
            habitAdapter.filter(currentQuery, currentCategory);
        });
    }

    private void setupRecyclerView() {
        habitAdapter = new HomeHabitAdapter(userHabits, new HomeHabitAdapter.OnHabitClickListener() {
            @Override
            public void onHabitClick(Habit habit) {
                boolean newState = !habit.isCompleted();
                habitRepository.updateHabitCompletion(habit.getId(), newState);
                
                // Refresh local list and UI
                userHabits = habitRepository.getUserHabits();
                updateAdapterData();
                updateOverallProgress();
            }

            @Override
            public void onHabitDetailClick(Habit habit) {
                Intent intent = new Intent(requireContext(), HabitDetailActivity.class);
                intent.putExtra(HabitDetailActivity.EXTRA_HABIT, habit);
                startActivity(intent);
            }
        });
        rvHabits.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvHabits.setAdapter(habitAdapter);
    }

    private void updateAdapterData() {
        habitAdapter.updateList(userHabits);
    }

    private void updateOverallProgress() {
        int count = 0;
        for (Habit h : userHabits) {
            if (h.isCompleted()) count++;
        }

        int total = userHabits.size();
        int progress = total > 0 ? (count * 100) / total : 0;

        pbMain.setProgress(progress);
        tvPercentage.setText(getString(R.string.percentage_format, progress));
    }
}